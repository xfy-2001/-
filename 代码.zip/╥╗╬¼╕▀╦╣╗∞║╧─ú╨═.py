# —*- coding=utf-8 -*-
# @Time:2022/4/1613:44
# @Author:芥末
# @Software:PyCharm
"""
一维情形
"""
import numpy as np
import random
import matplotlib.pyplot as plt
import seaborn as sns
def CreatData(mulist,sigmalist,N):
    Data=[]
    K=len(mulist)
    for j in range(N):
        i=random.randint(0,K-1)#随机产生一个0~n-1中的数
        data=np.random.normal(mulist[i],sigmalist[i],1)#产生服从正态分布的随机数
        Data.append(data)
    # print(Data)
    Data=np.array(Data)#将列表转换成数组
    return Data

#高斯分布概率计算公式
def GaussProb(x, mu, sigma):
    e = np.exp(-(np.power(x - mu, 2)) / (2 * np.power(sigma, 2)))
    Prob = (1 / (np.sqrt(2 * np.pi) * sigma)) * e
    return Prob

#E步
def Estep(Y,mulist,sigmalist,alphalist,K):
    gamma=[]#所有样本的gamma
    for j in range(len(Y)):
        y_j=Y[j]
        gammalist=[]#储存每一个样本的gamma
        for k in range(K):
            alpha_k=alphalist[k]
            mu_k=mulist[k]
            sigmak=sigmalist[k]
            gamma_jk=alpha_k*GaussProb(y_j,mu_k,sigmak)
            gammalist.append(gamma_jk)
        for i in range(len(gammalist)):
            gammalist[i]=gammalist[i]/sum(gammalist)
            #计算gamma_jk，表示的是当先模型参数下，属于第k个类别的概率
        gamma.append(gammalist)
    gamma=np.array(gamma).reshape(len(Y),K)#转换成数组，方便后面计算
    # print("gamma值",gamma)
    return gamma

#M步
def Mstep(gamma,Y,K):
    fenmu=np.sum(gamma,axis=0)
    mu_k=[np.dot(gamma[:,k],Y) for k in range(K)]
    mulist=[]
    for k,(mk,fen) in enumerate(zip(mu_k,fenmu)):
        muk=mk/fen
        mulist.append(muk)
    sigma2_k=[np.dot(gamma[:,k],(Y-mulist[k])**2) for  k in range(K)]
    sigmalist=[]
    for k ,(sigma,fen)in enumerate(zip(sigma2_k,fenmu)):
        a=sigma/fen
        sigmak=np.sqrt(a)
        sigmalist.append(sigmak)
    alphalist=fenmu/len(Y)
    return mulist,sigmalist,alphalist

def EM(Y,mulist,sigmalist,alphalist,K,maxiter=10000,epsilon=1e-5):
    i=0
    gammaiters=[]
    while i < maxiter:
        gamma=Estep(Y,mulist,sigmalist,alphalist,K)
        gammaiters.append(gamma)
        mulist_old, sigmalist_old=mulist,sigmalist
        mulist,sigmalist,alphalist=Mstep(gamma,Y,K)
        i=i+1
        if sum(sum(abs(np.array(mulist)-np.array(mulist_old)))+
               sum(abs(np.array(sigmalist))-np.array(sigmalist_old)))<epsilon:
            break
    probs=gammaiters[-1]
    prediction=[np.argmax(probs[j])for j in range(len(Y))]
    return mulist,sigmalist,alphalist,probs,prediction

if __name__ == '__main__':
    Data=CreatData([5,2,-1],[1,1,1],2000)
    print(Data)
    sns.set()
    sns.distplot(Data, bins=10, kde_kws={"color":"red","label":'密度曲线'},label="数据分布")
    # plt.show()
    #给初始值
    mulist0=[0,0,0]
    sigmalist0=[1,1,1]
    alphalist0=[0.3,0.3,0.4]
    mulist, sigmalist, alphalist,probs,prediction=EM(Data,mulist0,sigmalist0,alphalist0,3)
    print('EM算法得到的均值估计:\n',mulist,'\nEM算法得到的sigma估计:\n',sigmalist,
          '\nEM算法得到的alpha:\n',
          alphalist,'\nEM算法得到的每一类概率:\n',probs,'\nEM算法得到的类别预测:\n',prediction)
    # gamma=Estep(Data,mulist0,sigmalist0,alphalist0,3)
    # print(gamma,len(gamma))

    x=np.arange(-5,10,0.05)
    y=alphalist[0]*GaussProb(x,mulist[0],sigmalist[0])+\
      alphalist[1]*GaussProb(x, mulist[1], sigmalist[1])\
      +alphalist[2]*GaussProb(x, mulist[2], sigmalist[2])
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.legend(loc="upper right")
    plt.plot(x,y,label="拟合的高斯混合分布")
    plt.legend()
    plt.show()
