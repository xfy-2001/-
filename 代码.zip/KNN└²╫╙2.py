# —*- coding=utf-8 -*-
# @Time:2022/3/2711:08
# @Author:芥末
# @File:KNN例子2.py
# @Software:PyCharm
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import operator
from sklearn.model_selection import KFold
df=pd.read_csv("CityFire.csv")
print("该数据集共有{} 行{}列".format(df.shape[0],df.shape[1]))
df=np.array(df)
#对数据进行归一化处理
def NormMat(datamat):
    LabelVector = datamat[:,11]  # 分类特征
    datamat=datamat[:,:11]#提取特征
    minValue = datamat.min(0)
    maxValue = datamat.max(0)
    # 最大值和最小值的范围
    ranges = maxValue - minValue
    m = datamat.shape[0]
    normData = datamat - np.tile(minValue, (m, 1))#重复函数
    # 除以最大和最小值的差,得到归一化数据
    normData = normData / np.tile(ranges, (m, 1))
    NormData=np.zeros([m,12])
    NormData[:,0:11]=normData
    NormData[:,11]=LabelVector
    # size=NormData.shape[1]
    # print(size)
    return NormData, ranges, minValue,maxValue

#KNN分类  #定义距离 p是参数  1为曼哈顿距离  2为欧氏距离
# x待分类数据  data矩阵    k个临近点
def classfy(x,data,p,k):
    # m= data.shape[0]
    # print(m,n)
    # label=np.zeros([m,1])
    label=data[:,11]#分类特征
    # print(label)
    data=data[:,0:11]
    datasize=data.shape[0]
    x=x[0:11]
    # print(data,datasize,label)
    Distance=(abs(np.tile(x, (datasize, 1)) - data)**p).sum(axis=1)
    Distance=Distance**1/p
    #对距离进行升序排序，得到索引
    SortDistance=Distance.argsort()
    # print(len(SortDistance))
    # 定一个记录类别次数的字典
    classCount = {}
    for i in range(k):
        # 取出前k个元素的类别
        votelabel = int(label[SortDistance[i]])
        # print(SortDistance[i])
        # print(type(label[SortDistance[i]]))
        # 计算类别次数
        classCount[votelabel] = classCount.get(votelabel, 0) + 1
    sortedClassCount = sorted(classCount.items(), key=operator.itemgetter(1), reverse=True)
    # 返回次数最多的类别,即所要分类的类别
    return sortedClassCount[0][0]

# 数据集划分 训练数据集、测试数据集
def datacut(normData):
    kf = KFold(n_splits=5, shuffle=True)  # 初始化KFOLD
    train_files = []  # 存放5折的训练集划分
    test_files = []  # # 存放5折的测试集集划分
    for k, (Trindex, Tsindex) in enumerate(kf.split(normData)):
        train_files.append(np.array(normData)[Trindex].tolist())
        test_files.append(np.array(normData)[Tsindex].tolist())
    # # # 把划分写入csv,检验每次是否相同
    # dataTrain = pd.DataFrame(data=train_files, index=['0', '1', '2', '3', '4'])
    # dataTrain.to_csv('train_patch.csv')
    # dataTest = pd.DataFrame(data=test_files, index=['0', '1', '2', '3', '4'])
    # dataTest.to_csv('test_patch.csv')
    # # 划分数据集
    # for train_index, test_index in kf.split(normData):  # 调用split方法切分数据
    #     # print('train_index:%s , test_index: %s ' % (train_index, test_index))
    #     dataTrain, labelTrain = normData[train_index], LabelVector[train_index]
    #     dataTest, lableTest = normData[test_index], LabelVector[test_index]
    for j in range(5):
        dataTrain, dataTest = train_files[j], test_files[j]
        # print(dataTrain)
        dataTrain = np.array(dataTrain)
        dataTest = np.array(dataTest)
        # a = dataTest.shape[0]
        print(dataTrain.shape, dataTest.shape)
    return train_files,test_files

#交叉验证
def testclass():
    #数据归一化
    normData, ranges, minValue,maxValue = NormMat(df)
    # 采用五折交叉验证
    DataTrain, DataTest=datacut(normData)
    err = np.zeros([20,5])
    for k in range(1, 21):
        for j in range(5):
            dataTrain, dataTest = DataTrain[j], DataTest[j]
            # print(dataTrain)
            dataTrain = np.array(dataTrain)
            dataTest = np.array(dataTest)
            # a = dataTest.shape[0]
            print(dataTrain.shape, dataTest.shape)
            m=dataTest.shape[0]
            errcount = 0
            for i in range(m):
                # #p  距离  k临近点
                classresult = classfy(dataTest[i, :], dataTrain, p=2, k=k)
                if classresult != dataTest[i,11]:
                    errcount += 1
                    # print("分类结果:%d\t真实类别:%d" % (classresult, labelTrain[i]))
            err[k - 1,j] = errcount / float(m)
    # print("错误率:" ,err)
    err=np.average(err,axis=1)
    x=len(err)
    print("错误率:" ,err)
    Minerr=min(err)
    bestnum=err.argmin()+1
    print("错误率最低的k是:{}" .format(bestnum),"其值为:{}".format(Minerr))
    return err ,x,Minerr,bestnum
def figure(x,err,Minerr,bestnum):
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    x=range(1,x+1)
    # plt.plot(x,err,label='曼哈顿距离')
    plt.plot(x,err, label='欧式距离')
    # plt.plot(x, err, label='l_3距离')
    #标记出最优的K值
    plt.scatter([bestnum],[Minerr],marker="*",color='red',s=50)
    plt.legend(loc="upper right")
    plt.xlabel('k近邻')
    plt.ylabel('错误率')
    plt.show()

if __name__ == '__main__':
    err,x,Minerr,bestnum=testclass()
    figure(x,err,Minerr,bestnum)




