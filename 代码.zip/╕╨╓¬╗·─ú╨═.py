# —*- coding=utf-8 -*-
# @Time:2022/3/1213:34
# @Author:芥末
# @File:感知机模型.py
# @Software:PyCharm
import numpy as np
from matplotlib import pyplot as plt
#数据读取
def data():
    traindata=[((3,3),1),((4,3),1),((1,1),-1)]
    feature=[]
    label=[]
    for i in traindata:
        feature.append(i[0])
        label.append(i[1])
    feature=np.array(feature)
    label=np.array(label)
    return feature,label
#随机梯度下降法
#参数w,b,取eta为1
def train(feature,label):
    w = np.array([0, 0])
    b = 0
    eta = 1
    stop=True
    while stop:
        count=len(feature)
        for i in range(len(feature)):
            if label[i]*(np.dot(w,feature[i])+b)<=0:
                print("此为误分类点:",feature[i],"此时w为:",w,"此时b为:",b)
                w = w + eta * feature[i]*label[i]
                b = b + eta * label[i]
            else:
                count-=1
        if count ==0:
            stop=False
    print("最终w:",w,"最终b:",b)
    return  w,b

if __name__ == '__main__':
    feature,label=data()
    x=np.array(feature)
    y=np.array(label)
    w,b=train(x,y)
