# —*- coding=utf-8 -*-
# @Time:2022/3/2018:13
# @Author:芥末
# @File:KNN实现.py
# @Software:PyCharm

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import operator
from sklearn.model_selection import KFold
#导入数据
df=pd.read_csv("abalone.csv")
print("该数据集共有 {} 行 {} 列".format(df.shape[0],df.shape[1]))

#数据预处理
df1=df.loc[:,"Rings"].value_counts()
df1=df1.reset_index()
print(df1)
print("该数据集共有个{}标签".format(len(df1)))
# 这两行代码解决 plt 中文显示的问题
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
#数据可视化，查看标签分布情况
sns.barplot(x = 'index', y = 'Rings', data = df1, palette="rocket").set_title("标签分布情况")
plt.xlabel('标签')
plt.ylabel('频数')
plt.show()

#对sex数据进行编码 M :1 F :-1 (infant):0
def data():
    df = pd.read_csv("abalone.csv")
    def label(df):
        if df["Sex"] == "M":
            return 1
        elif df["Sex"] == "F":
            return -1
        else:
            return 0
    df['Sex'] = df.apply(label, axis=1)
    df[['Sex']] = df[['Sex']].astype("float64")
    df2=np.array(df)
    return df2


# 根据标签分布对标签进行划分划成七个区间
def filematrix(dataset):
    RowLines =dataset.shape[0]
    # LabelVector=np.zeros(RowLines)
    #分类标签
    returnMat= dataset[:,0:8]
    # mm=returnMat.shape[1]
    # print(mm)
    LabelVector=dataset[:,8]
    # print(LabelVector)
    for i in range(RowLines):
        if (dataset[i][8] > 0 and dataset[i][8] < 5):
            LabelVector[i] = 1
        elif (dataset[i][8] >= 5 and dataset[i][8] < 9):
            LabelVector[i] = 2
        elif (dataset[i][8] >= 9 and dataset[i][8] < 13):
            LabelVector[i] = 3
        elif (dataset[i][8] >= 13 and dataset[i][8] < 17):
            LabelVector[i] = 4
        elif (dataset[i][8] >= 17 and dataset[i][8] < 21):
            LabelVector[i] = 5
        elif (dataset[i][8] >= 21 and dataset[i][8] < 25):
            LabelVector[i] = 6
        elif (dataset[i][8] >= 25 and dataset[i][8] < 30):
            LabelVector[i] = 7
    return returnMat, LabelVector

#对数据进行归一化处理
def NormMat(datamat):
    minValue = datamat.min(0)
    maxValue = datamat.max(0)
    # 最大值和最小值的范围
    ranges = maxValue - minValue
    m = datamat.shape[0]
    normData = datamat - np.tile(minValue, (m, 1))#重复函数
    # 除以最大和最小值的差,得到归一化数据
    normData = normData / np.tile(ranges, (m, 1))
    return normData, ranges, minValue,maxValue

#KNN分类  #定义距离 p是参数  1为曼哈顿距离  2为欧氏距离
# x待分类数据  data特征矩阵  lable类别  k个临近点
def classfy(x,data,label,p,k):
    datasize=data.shape[0]
    Distance=(abs(np.tile(x, (datasize, 1)) - data)**p).sum(axis=1)
    Distance=Distance**1/p
    #对距离进行升序排序，得到索引
    SortDistance=Distance.argsort()
    # 定一个记录类别次数的字典
    classCount = {}
    for i in range(k):
        # 取出前k个元素的类别
        votelabel = label[SortDistance[i]]
        # 计算类别次数
        classCount[votelabel] = classCount.get(votelabel, 0) + 1
    sortedClassCount = sorted(classCount.items(), key=operator.itemgetter(1), reverse=True)
    # 返回次数最多的类别,即所要分类的类别
    return sortedClassCount[0][0]

# 数据集划分
def datacut(normData,LabelVector):
    kf = KFold(n_splits=5, shuffle=False)#采用五折交叉验证方法
    # 划分数据集
    for train_index, test_index in kf.split(normData):  # 调用split方法切分数据
        # print('train_index:%s , test_index: %s ' % (train_index, test_index))
        dataTrain, labelTrain = normData[train_index], LabelVector[train_index]
        dataTest, lableTest = normData[test_index], LabelVector[test_index]
    return dataTrain,dataTest,labelTrain,lableTest

#交叉验证
def testclass():
    #编码后数据
    df2 = data()
    # print(df2)
    #特征矩阵和类别
    returnMat, LabelVector = filematrix(df2)
    #数据归一化
    normData, ranges, minValue,maxValue = NormMat(returnMat)
    # 采用五折交叉验证
    dataTrain, dataTest, labelTrain, lableTest=datacut(normData,LabelVector)
    m=dataTrain.shape[0]
    err=np.zeros(20)
    x=len(err)
    for k in range(1,21):
        errcount=0
        for i in range(m):
            # #p  距离  k临近点
            classresult = classfy(dataTrain[i, :], dataTest, lableTest, p=2, k=k)
            if classresult != labelTrain[i]:
                errcount += 1
                # print("分类结果:%d\t真实类别:%d" % (classresult, labelTrain[i]))
        err[k-1]=errcount / float(m)
    print("错误率:" ,err)
    Minerr = min(err)
    bestnum = err.argmin() + 1
    print("错误率最低的k是:%d" % ((err.argmin())+1),"其值为:{}".format(err[err.argmin()]))
    return err ,x,Minerr,bestnum
def figure(x,err,Minerr,bestnum):
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    x=range(1,x+1)
    # plt.plot(x,err,label='曼哈顿距离')
    plt.plot(x,err, label='欧式距离')
    # plt.plot(x, err, label='l_3距离')

    # 标记出最优的K值
    plt.scatter([bestnum],[Minerr],marker="*",color='red',s=50)
    plt.legend(loc="upper right")
    plt.xlabel('k近邻')
    plt.ylabel('错误率')
    plt.show()

if __name__ == '__main__':
    err,x,Minerr,bestnum=testclass()
    figure(x,err,Minerr,bestnum)





