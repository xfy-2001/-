# —*- coding=utf-8 -*-
# @Time:2022/3/1219:20
# @Author:芥末
# @File:感知机对偶形式.py
# @Software:PyCharm
import numpy as np
#数据读取
def data():
    traindata=[((3,3),1),((4,3),1),((1,1),-1)]
    feature=[]
    label=[]
    for i in traindata:
        feature.append(i[0])
        label.append(i[1])
    feature=np.array(feature)
    label=np.array(label)
    Gram=np.zeros((len(feature),len(feature)))
    #计算Gram矩阵
    for i in range(len(feature)):
        for j in range(len(feature)):
            Gram[i][j]=np.dot(feature[i],feature[j])
    Gram=np.array(Gram)
    return feature,label,Gram
#随机梯度下降法
#参数alpha,b,取eta为1
def train(feature,label):
    w = np.zeros(len(label))
    b = 0
    eta = 1
    alpha=np.zeros(len(label))
    stop=True
    while stop:
        count=len(feature)
        for i in range(len(feature)):
            s=0
            for j in range(len(feature)):
                s+=alpha[j]*label[j]*Gram[i][j]
            if label[i]*(s+b)<=0:
                print("此为误分类点:",feature[i],"此时alpha为:",alpha,"此时b为:",b)
                alpha[i] = alpha[i] + eta
                b = b + eta * label[i]
            else:
                count-=1
        if count ==0:
            stop=False
    w=np.dot(alpha*label,feature)
    print("最终alpha:",alpha,"最终b:",b,"最终w为",w)
    return alpha,b,w

if __name__ == '__main__':
    feature,label,Gram=data()
    x=np.array(feature)
    y=np.array(label)
    alpha,b,w=train(x,y)


