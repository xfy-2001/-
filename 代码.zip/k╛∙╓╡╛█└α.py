# —*- coding=utf-8 -*-
# @Time:2022/5/2914:36
# @Author:芥末
# @File:k均值聚类.py
# @Software:PyCharm
import numpy as np
import random
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris

# 导入Iris数据集
iris = load_iris()
label1 = np.array(iris.target)
data = np.array(iris.data)


# print("Iris数据集的标签：\n",label1,data)

# 生成模拟数据
def CreatData(mulist, covlist, N):
    Data = []
    label = []  # 每一个数据来自哪一个分布的标签值
    K = len(mulist)  # k各类别
    for j in range(N):
        i = random.randint(0, K - 1)  # 随机产生一个0~n-1中的数
        data = np.random.multivariate_normal(mulist[i], covlist[i], 1)
        # 产生服从正态分布的随机数
        Data.append(data)
        labeli = i
        label.append(labeli)
    # print(Data)
    Data = np.array(Data)  # 将列表转换成数组
    return Data, label


# k均值聚类
# 初始化聚类中心
def Rcenters(data, K):
    n = np.shape(data)[1]
    centers = np.zeros([K, n])
    for i in range(n):
        mink = np.min(data[:, i])
        maxk = np.max(data)
        temp = np.random.uniform(mink,maxk,(K,1))
        temp = np.reshape(temp, K)
        # print(temp)
        # print(centers[:,i])

        centers[:, i] = temp
    # print(centers)
    return centers
def k_meanscluster(data, K, p=2):
    # 初始化聚类中心
    centers = Rcenters(data, K)
    print(centers, '初始聚类中心')
    m = np.shape(centers)[1]
    n = np.shape(data)[0]
    dis = np.zeros([n, K + 1])
    stop = True
    while stop:
        # 求各个点到类中心的距离
        for i in range(n):
            for k in range(K):
                dis[i, k] = np.sum(abs(data[i, :] - centers[k, :]) ** p)
            # 归类
            dis[i, K] = np.argmin(dis[i, :K])  # 距离最小的索引
        # print(dis)
        centers_new = np.zeros([K, m])
        # 更新聚类中心
        for k in range(K):
            data_new = data[np.nonzero(dis[:, K] == k)[0]]  # 找出同一类的数据
            """
            查看迭代过程,
            """
            #绘制每一次迭代的图
            plt.scatter(data_new[:, 0], data_new[:, 1])

            # print(data_new,'数组')
            if data_new.size != 0:
                centers_new[k, :] = np.mean(data_new, axis=0)  # 求列平均
            else:
                centers_new[k, :] = centers[k, :]
                """
                标记出聚类中心点
                """
        # print(centers_new[:,0],'kankan',centers_new[:,1])
        plt.scatter(centers_new[:, 0], centers_new[:, 1], marker="*", color='red', s=50)
        plt.show()

        # print(centers_new, 'centernew')
        # 判别,满足条件跳出循环
        t = np.sum(centers_new - centers)
        t = np.sum(t)
        # print(t)
        if t == 0:
            stop = False
        # 否则继续
        centers = centers_new
    print(centers, "聚类中心")
    return dis, centers


if __name__ == '__main__':
    mulist = [[-4, 5], [0, 0], [7, 7]]
    mu = np.array(mulist)
    covlist = [[[2, 1], [1, 2]], [[2, 1], [1, 2]], [[2, 1], [1, 2]]]
    cov = np.array(covlist)
    Data, label = CreatData(mu, cov, 300)
    Data1 = Data.reshape(300, 2)
    # print(Data1,'数据')

    '''画出原始数据二维平面分布'''
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    x = Data1[:, 0]
    Y = Data1[:, 1]
    plt.scatter(x, Y, c=label)
    plt.title('数据分布')
    plt.show()
    """
    1、自己模拟的数据
    """
    dis1,centers1 = k_meanscluster(Data1, 3)

    
    """
    2、Iris数据集
    """
    # x1 = data[:, 0]
    # x2 = data[:, 1]
    # plt.scatter(x1, x2, c=label1)
    # plt.title('数据分布')
    # # plt.show()
    # dis2,centers2=k_meanscluster(data,3)
