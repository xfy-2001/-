# —*- coding=utf-8 -*-
# @Time:2022/5/1610:17
# @Author:芥末
# @File:EM混合高斯模型.py
# @Software:PyCharm
import numpy as np
import random
import matplotlib.pyplot as plt
#高维情形
#生成模拟数据
def CreatData(mulist,covlist,N):
    Data = []
    label=[]#每一个数据来自哪一个分布的标签值
    K = len(mulist)#k各类别
    for j in range(N):
        i = random.randint(0, K - 1)  # 随机产生一个0~n-1中的数
        data = np.random.multivariate_normal(mulist[i], covlist[i], 1)
        # 产生服从正态分布的随机数
        Data.append(data)
        labeli=i
        label.append(labeli)
    # print(Data)
    Data = np.array(Data)  # 将列表转换成数组
    return Data,label

#多维高斯分布
def GaussProb(x, mu,cov):
    N = len(mu)
    # print(N)
    # cov的行列式为零不可逆，对角线加上一个小的数
    covdet = np.linalg.det(cov + np.eye(N) * 0.001)
    covinv = np.linalg.inv(cov + np.eye(N) * 0.001)
    # print(x,'x是多少',mu)
    xdiff = (x - mu).reshape((1, N))
    # 概率密度
    Prob = 1.0 / (np.power(np.power(2 * np.pi, N) * np.abs(covdet), 0.5)) * \
           np.exp(-0.5 * xdiff.dot(covinv).dot(xdiff.T))[0][0]
    return Prob

#估计参数
#E步
def Estep(Y,mulist,covlist,alphalist,K):
    gamma=[]
    for j in range(len(Y)):
        y_j = Y[j]
        # print(Y,"HHHHH")
        gammalist = []
        for k in range(K):
            alpha_k = alphalist[k]
            mu_k = mulist[k]
            covk = covlist[k]
            gamma_jk = alpha_k * GaussProb(y_j, mu_k, covk)
            gammalist.append(gamma_jk)
        for i in range(len(gammalist)):
            gammalist[i] = gammalist[i] / sum(gammalist)
            # 计算gamma_jk，表示的是当先模型参数下，属于第k个类别的概率
        gamma.append(gammalist)
    gamma = np.array(gamma).reshape(len(Y), K)  # 转换成数组，方便后面计算
    # print("gamma值",gamma,gamma.shape)
    return gamma

#M步
def Mstep(gamma,Y,K):
    mulist = []
    covlist=[]
    N,dim=Y.shape
    fenmu = np.sum(gamma, axis=0)
    # print(fenmu,'分母')
    mu_k = [np.dot(gamma[:, k], Y) for k in range(K)]
    for k,(mk,fen) in enumerate(zip(mu_k,fenmu)):
        muk=mk/fen
        mulist.append(muk)
    # print(mulist,'均值向量')
    mu=np.array(mulist)
    y_diff=[(Y-np.tile(mu[k],(N,1)))for k in range(K)]
    # print(y_diff,y_diff[1],type(y_diff[1]))
    y_diff=np.array(y_diff)
    slist=[]
    for k in range(K):
        y_diffk=y_diff[k]
        s=np.sum([gamma[j,k]*np.dot(y_diffk[j].reshape((dim,1)),y_diffk[j].reshape((1,dim)))
                  for j in range(N)],axis=0)
        slist.append(s)
    # print(slist,'juzh')
    for k,(sk,fen) in enumerate(zip(slist,fenmu)):
        covk=sk/fen
        covlist.append(covk)
    # print(covlist,'协方差矩阵')

    alphalist = fenmu / len(Y)
    alphalist=np.array(alphalist)
    mulist-np.array(mulist)
    return mulist,covlist,alphalist

#计算Q函数值
def Qfun(Y,gamma,alphalist,mulist,covlist,K):
    Qlist = []  # Q函数
    for j in range(len(Y)):
        s=[alphalist[k] * GaussProb(Y[j], mulist[k], covlist[k]) for k in range(K)]
        s=np.array(s)
        # print(s,'aaa')
        #防止出现0的情形
        temp = [np.sum(gamma[j,k] * np.log(s[k]+1e-5)) for k in range(K)]
        temp=sum(temp)
        # print(temp,type(temp),'aaannn')
        Qlist.append(temp)
    # print(Qlist)
    Q = sum(Qlist)
    # print(Q)
    return Q

#EM算法
def EM(Y,mulist,covlist,alphalist,K,maxiter=1000,epsilon=1e-5):
    i=0
    gammaiters=[]#为了后面可视化,储存每次迭代得到的gamma值
    Qiters=[]
    while i < maxiter:
        gamma=Estep(Y,mulist,covlist,alphalist,K)
        gammaiters.append(gamma)
        mulist_old, covlist_old=mulist,covlist
        mulist,covlist,alphalist=Mstep(gamma,Y,K)
        i=i+1
        Qold=Qfun(Y,gamma,alphalist,mulist_old,covlist_old,K)
        Q=Qfun(Y,gamma,alphalist,mulist,covlist,K)
        Qiters.append(Q)
        if abs(Q-Qold)<=epsilon:
            break
    probility=gammaiters[-1]
    prediction=[np.argmax(probility[j])for j in range(len(Y))]
    return mulist,covlist,alphalist,probility,prediction,Qiters,gammaiters

def draw_pie(dist,
             xpos,
             ypos,
             size,
             ax=None):
    if ax is None:
        fig, ax = plt.subplots(figsize=(10,8))
    cumsum = np.cumsum(dist)
    cumsum = cumsum/ cumsum[-1]
    # print(cumsum)
    pie = [0] + cumsum.tolist()
    # print(pie,pie[:-1],pie[1:],'pie')
    xy=[]
    for r1, r2 in zip(pie[:-1], pie[1:]):
        # print(r1,r2)
        angles = np.linspace(2 * np.pi * r1, 2 * np.pi * r2)
        x = [0] + np.cos(angles).tolist()
        y = [0] + np.sin(angles).tolist()
        # print(x,y)
        xy1 = np.column_stack([x, y])
        xy.append(xy1)
        #改代码只适合三类，如果类别增加或者减少，这部分代码需要改变
    ax.scatter([xpos], [ypos],marker=xy[0], s=size,facecolor='blue')
    ax.scatter([xpos], [ypos], marker=xy[1], s=size, facecolor='green')
    ax.scatter([xpos], [ypos], marker=xy[2], s=size, facecolor='red')

    return ax

if __name__ == '__main__':
    mulist = [[-5, -5], [2, 2], [10,10]]
    mu = np.array(mulist)
    covlist = [[[2,1],[1,2]],[[2,1],[1,2]],[[2,1],[1,2]]]
    cov = np.array(covlist)
    Data ,label= CreatData(mu, cov, 300)
    Data1 = Data.reshape(300, 2)
    # print(Data, len(Data), Data[0][0])
    # print(Data1)
    '''画出原始数据二维平面分布
    后续要根据这个二维图确定初始参数'''
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    x = Data1[:, 0]
    Y = Data1[:, 1]
    plt.scatter(x, Y,c=label)
    plt.title('数据分布')
    plt.show()

    # 根据数据原始分布,给初始值
    mulist0 = [[-5, -5], [2.5, 2.5], [10, 8]]
    sigmalist0 = [[[1, 0], [0, 1]], [[1, 0], [0, 1]], [[1, 0], [0, 1]]]
    alphalist0 = [0.4, 0.3, 0.3]
    #EM算法
    mulist, covlist, alphalist ,probility,prediction,Qiters,gammaiters= \
        EM(Data1, mulist0, sigmalist0, alphalist0, 3)
    print('EM算法得到的均值估计:\n',mulist, '\nEM算法得到的sigma估计:\n',
          covlist, '\nEM算法得到的alpha:\n',alphalist,'\nEM算法得到的每一类概率:\n',
          probility,'\nEM算法得到的类别预测:\n',prediction,'\n每次迭代的Q函数值\n',Qiters)
    #画出Q函数
    plt.plot(range(len(Qiters)),Qiters)
    plt.title('每次迭代Q函数值')
    plt.show()
    #根据EM算法得到的类别
    plt.scatter(x,Y,c=prediction)
    plt.title('EM预测出的类别')
    plt.show()

    #第一次迭代属于每一类的概率
    probi=gammaiters[1]
    fig, ax = plt.subplots(figsize=(10, 8))
    for i in range(len(x)):
        draw_pie(probi[i], xpos=x[i], ypos=Y[i], size=300, ax=ax)
    plt.title('第一次迭代的图')
    plt.show()

    #最终迭代结果，属于每一类的可能概率
    fig, ax = plt.subplots(figsize=(10, 8))
    for i in range(len(x)):
        draw_pie(probility[i],xpos=x[i],ypos=Y[i],size=300,ax=ax)
    plt.title('最终结果')
    plt.show()

    #准确率
    a=0
    for i in range(len(label)):
        if prediction[i]==label[i]:
            a+=1
    acc=a/len(label)
    print('准确率',acc)
