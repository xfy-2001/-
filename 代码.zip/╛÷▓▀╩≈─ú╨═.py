# —*- coding=utf-8 -*-
# @Time:2022/4/1719:45
# @Author:芥末
# @File:决策树模型
# @Software:PyCharm
import pandas as pd
import math
import numpy as np
import random

#读取数据
"""
说明：有两个数据集，每次运行一个，另一个注释掉
"""
def LoadData():
    #1、第一个数据集
    df = pd.read_csv("hayes-roth.csv")

    #2、第二个数据集
    # df = pd.read_csv("balance-scale.csv")

    print("该数据集共有{} 行{}列".format(df.shape[0], df.shape[1]))
    nfeature=df.shape[1]-1  #最后一列为label,故将其删除
    FeatureSet=list(df.columns.values)#数据集每一列的属性特征,存成列表
    FeatureSet=FeatureSet[:nfeature]
    print("数据集的特征集合为:",FeatureSet)
    DataSet=df.values#获取数据值
    # print(DataSet)
    return DataSet,FeatureSet


#切分数据,提取符合条件某特征某个值的数据集
def ClassData(DataSet,Feature,Value):
    Data1Set=[]
    # print(len(DataSet[0]))
    for item in DataSet:
        if item[Feature]==Value:
            item=list(item)
            # print(item,type(item))
            X1=item[:Feature]
            X2=item[Feature+1:]
            X1.extend(X2)#得到的数据除去该特征下
            Data1Set.append(X1)
    # print(len(Data1Set),Data1Set)
    return Data1Set

#计算熵
def ClaEntropy(DataSet):
    n=len(DataSet)
    LabelSet={}
    for item in DataSet:
        label=item[-1]#获取该行的label值
        if label not in LabelSet.keys():
            LabelSet[label]=0
        LabelSet[label]+=1
    # print(LabelSet,LabelSet.keys())
    Entropy=0
    for keylabel in LabelSet.keys():
        # 用频率估计概率
        Prob=float(LabelSet[keylabel])/n
        #计算熵
        Entropy -=Prob*math.exp(Prob)
    return Entropy

#计算信息增益,选择出最优的特征属性
def FindBestFeature(DataSet):
    nFeature=len(DataSet[0])-1#属性特征个数,最后一列是标签
    # print(nFeature)
    HEntropy=ClaEntropy(DataSet)
    # print(HEntropy)
    InfoGains=[]
    for i in range(nFeature):
        Featurevalues=[item[i] for item in DataSet]
        values=np.unique(Featurevalues)#属性对应的值
        ConditionEntropy=0
        for value in values:
            SubDataSet=ClassData(DataSet,i,value)#调用划分数据的函数，得到子数据集，用子数据集计算熵
            Prob=len(SubDataSet)/float(len(DataSet))#某特征某个值的概率
            ConditionEntropy +=Prob*ClaEntropy(SubDataSet)#计算条件熵
            # print(ConditionEntropy)
        InfoGain=HEntropy-ConditionEntropy#信息增益
        InfoGains.append(InfoGain)
    # print(InfoGains)
    BestFeature=InfoGains.index(max(InfoGains))#得到信息增益最大的特征索引
    # print("最大的信息增益索引为{}".format(BestFeature))
    infogain=max(InfoGains)#信息增益最大值
    return BestFeature,infogain

#计算出现次数最多的类别
def MaxCountLable(ClassSet):
    LableCount={}
    for i in ClassSet:
        if i not in LableCount.keys():
            LableCount[i]=0
            LableCount[i]+=1
    Lable=max(LableCount, key=LableCount.get)
    return Lable

#建立决策树
#epsilon为特征集信息增益阈值
def CreateTree(DataSet,FeatureSet,BestFeatureSet,epsilon=0.001):
    #取分类标签
    ClassSet=[example[-1] for example in DataSet]
    """
    递归返回的三种情形
    """
    #1、如果类别完全相同，则停止继续划分
    if len(np.unique(ClassSet))==1:
        return ClassSet[0]
    #2、如果特征标签用完了，则返回出现次数最多的标签
    if len(FeatureSet)==0:
        return MaxCountLable(ClassSet)
    #选择最优特征
    BestFeature,infogain=FindBestFeature(DataSet)
    #3、如果最大信息增益小于阈值，递归返回
    if infogain<=epsilon:
        return MaxCountLable(ClassSet)

    #最优特征的标签
    BestFeaturevalue=FeatureSet[BestFeature]
    BestFeatureSet.append(BestFeaturevalue)
    #根据最优特征的标签生成树
    Tree={BestFeaturevalue:{}}
    #删除已经使用的特征标签
    del(FeatureSet[BestFeature])
    #得到训练集中所有最优特征的属性值
    IndexValues=[item[BestFeature] for item in DataSet]
    #去掉重复的属性值
    values=np.unique(IndexValues)
    #遍历特征，创建决策树
    for value in values:
        Tree[BestFeaturevalue][value]=CreateTree(ClassData(DataSet,BestFeature,value),
                                               FeatureSet,BestFeatureSet,epsilon=0.001)
    return Tree

#预测分类
def Classify(Tree,BestFeatureSet,testdata):
    #获取决策树节点
    NodeName=next(iter(Tree))#对节点进行迭代
    # print(NodeName)
    NodeValue=Tree[NodeName]
    # print(NodeValue)
    # print(BestFeatureSet)
    FeatureIndex=BestFeatureSet.index(NodeName)
    ClassLable=None
    for key in NodeValue.keys():
        if testdata[FeatureIndex]==key:
            if type(NodeValue[key])==dict:#如果仍为字典格式则继续递归
                ClassLable=Classify(NodeValue[key],BestFeatureSet,testdata)
            else: ClassLable=NodeValue[key]
    # print('分类标签为:',ClassLable)
    return ClassLable

#划分训练数据集和测试数据集,采用简单交叉验证,Ratio是测试数据集占比
"""
shuffle=True重新洗牌，每次划分的数据集都不一样
为了模型可以再现，故这里选择不重新洗牌
"""
def SplitData(DataSet,Ratio,shuffle=False):
    Ntotal=len(DataSet)
    m=int(Ntotal*Ratio)
    if Ntotal==0 or m<1:
        return [],DataSet
    if shuffle:
        random.shuffle(DataSet)#将数据打乱
    testdata=DataSet[:m]
    traindata=DataSet[m:]
    return traindata,testdata


#模型错误率
def TestErr(Tree,testdata,BestFeatureSet):
    errnum=0
    predicts=[]#用列表存储模型预测分类
    for i in range(len(testdata)):
        test=testdata[i]
        # print(test)
        n=len(test)-1#最后一列是label
        test=test[:n]
        predict=Classify(Tree,BestFeatureSet,test)
        predicts.append(predict)
        if predict != testdata[i][-1]:
            errnum+=1
    err=errnum/float(len(testdata))
    print("模型的预测结果为:\n{}".format(predicts))
    print("模型的错误率为:{}".format(err))
    return err

if __name__=='__main__':
    dataSet,labels=LoadData()
    # print(labels)
    traindata,testdata=SplitData(dataSet,0.1)
    # print(testdata)
    BestFeatureSet = []
    Tree=CreateTree(traindata,labels,BestFeatureSet,epsilon=0.001)
    print("生成的决策树为:\n", Tree)
    y=TestErr(Tree,testdata,BestFeatureSet)



