# —*- coding=utf-8 -*-
# @Time:2022/3/2410:58
# @Author:芥末
# @File:朴素贝叶斯.py
# @Software:PyCharm
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold

df = pd.read_csv("CityFire.csv")
print("该数据集共有{} 行{}列".format(df.shape[0], df.shape[1]))


# 划分训练数据集和测试数据集
def Datacut(df):
    kf = KFold(n_splits=5, shuffle=True)  # 初始化KFOLD
    train_files = []  # 存放5折的训练集划分
    test_files = []  # # 存放5折的测试集集划分
    for k, (Trindex, Tsindex) in enumerate(kf.split(df)):
        train_files.append(np.array(df)[Trindex].tolist())
        test_files.append(np.array(df)[Tsindex].tolist())
    for j in range(5):
        dataTrain, dataTest = train_files[j], test_files[j]
        # print(dataTrain)
        dataTrain = np.array(dataTrain)
        dataTest = np.array(dataTest)
        print("训练数据集大小为:{},测试数据集大小为:{}".format(dataTrain.shape, dataTest.shape))
        # #打印数据大小
    return train_files, test_files


# 按类别划分数据集  最后一列分类标签
def ClassData(dataset):
    classdata = {}
    for i in range(len(dataset)):
        label = dataset[i]
        if (label[-1] not in classdata):
            classdata[label[-1]] = []
        classdata[label[-1]].append(label)
        # print(classdata)
    # 打印分割数据
    return classdata


# 计算均值和标准差
def mean(num):
    mu = sum(num) / float(len(num))
    return mu


def std(num):
    avg = mean(num)
    var = sum([pow(x - avg, 2) for x in num]) / float(len(num) - 1)
    sd = np.sqrt(var)
    return sd


# 提取特征属性  每个特征的均值和标准差
def SummaryFeature(dataset):
    summary = [(mean(item), std(item)) for item in zip(*dataset)]  # zip(*)解压，返回二维矩阵式
    del summary[-1], summary[0]  # 去掉第一列和最后一列  第一列为离散情况  最后一列是标签
    return summary


# 提取每个标签下的  每个特征集合的均值和标准差
def SummaryLabel(dataset):
    classdata = ClassData(dataset)  # 按标签划分数据集
    datasetsummary = {}
    for keyClass, instances in classdata.items():
        datasetsummary[keyClass] = SummaryFeature(instances)  # 获得均值和方差
    return datasetsummary


# 先验概率
def Priorprobability(datatrain):
    m = datatrain.shape[0]  # 标签总个数
    Prior = {}
    classdata = ClassData(datatrain)
    for keyClass, classSummary in classdata.items():
        X = np.array(classSummary)[:, 0]  # 将字典值转换成数组格式
        Prior[keyClass] = len(X)  # 获取每一个标签的个数
    for i in Prior:
        Prior[i] = (Prior[i] + 1) / (m + len(Prior))  # lambda=1
        # print(Prior)
    return Prior


# 1、离散
# 条件概率 （用频率估计概率）给定标签  #默认lamda为1
# 离散  x为输入的离散特征取值
def ProbL(datatrain, x):
    m = datatrain.shape[0]
    ncount = 0
    for i in range(m):
        if x == datatrain[i, 0]:  # 第一列为离散特征所以取出第一列
            ncount += 1
    # print(ncount)
    Set = {}
    classdata = ClassData(datatrain)
    for keyClass, classSummary in classdata.items():
        X = np.array(classSummary)[:, 0]  # 将字典值转换成数组格式
        count = 0
        for j in range(len(X)):
            if x == X[j]:
                count += 1
        # print(count)
        Set[keyClass] = count
        # print(Set)
    for i in Set:
        Set[i] = (Set[i] + 1) / (ncount + len(Set))  # lambda=1
        # print(Set)
    return Set


# 2、连续(假设服从正态分布）#估计均值 mu 估计标准差 sd
def NormProbability(x, mu, sd):
    e = np.exp(-(np.power(x - mu, 2)) / (2 * np.power(sd, 2)))
    NormProb = (1 / (np.sqrt(2 * np.pi) * sd)) * e
    return NormProb


# 计算给定样本属于每一个标签概率 连续变量概率 （假设条件概率相互独立）
def ContinuousProbabilities(datasetsummary, xvector):
    probabilities = {}
    for keyClass, classSummary in datasetsummary.items():  # 对应类别和数据
        probabilities[keyClass] = 1
        for i in range(len(classSummary)):
            mu, sd = classSummary[i]
            x = xvector[i]
            probabilities[keyClass] *= NormProbability(x, mu, sd)  # 条件概率连乘
        # print(probabilities)
    return probabilities


# 实例预测 （后验概率最大化决策）
def BayesPredict(dataset, datasetsummary, xvector):
    Prior = Priorprobability(dataset)  # 先验概率
    Prob = ContinuousProbabilities(datasetsummary, xvector)  # 连续情形
    Set = ProbL(dataset, xvector[0])  # 离散情形条件概率
    # 将离散特征与连续特征条件概率相乘得到每个特征的后验概率
    for i in Prob:
        Prob[i] = Prior[i] * Prob[i] * Set[i]
    # print(Prob)
    # 找出概率最大的标签的键值对
    BestLabel, BestProb = max(Prob.items(), key=lambda x: x[1])
    # 返回预测标签
    return BestLabel


# 数据集预测
def BayesPredictions():
    train_files, test_files = Datacut(df)
    # 模型评估交叉验证
    err = np.zeros([5, 1])  # 生成数组来存取每次交叉验证误差
    predictions = {}  # 用字典来存每次交叉验证预测的结果
    # 每次取一份来训练模型，对模型进行评估
    for i in range(5):
        datatrian, datatest = train_files[i], test_files[i]
        datatrian = np.array(datatrian)
        datatest = np.array(datatest)
        errcount = 0
        results = []  # 用列表存取每次预测的结果
        for j in range(len(datatest)):
            datasetsummary = SummaryLabel(datatrian)  # 提取特征
            result = BayesPredict(datatrian, datasetsummary, datatest[j])
            results.append(result)
            if result != datatest[j, -1]:  # 预测不等于真实的
                errcount += 1
                # print("分类结果:%d\t真实类别:%d" % (result, datatest[j,-1]))
        predictions[i] = results
        err[i] = errcount / float(len(datatest))
    print("每次交叉验证模型错误率:\n{}".format(err))
    print("每折预测结果为:\n{}".format(predictions))
    # 对交叉验证误差取平均，用均值来估计误差
    err = np.average(err)
    return err, predictions


if __name__ == '__main__':
    err, predictions = BayesPredictions()
    print("交叉验证模型评估结果为:{}".format(err))
