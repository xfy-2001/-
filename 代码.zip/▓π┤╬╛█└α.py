# —*- coding=utf-8 -*-
# @Time:2022/5/2814:33
# @Author:芥末
# @File:层次聚类.py
# @Software:PyCharm

import numpy as np
import random
import matplotlib.pyplot as plt
from operator import itemgetter
from collections import OrderedDict, Counter
from sklearn.datasets import load_iris

"""
1、数据集一:导入Iris数据集
"""
iris = load_iris()
label1 = np.array(iris.target)
data = np.array(iris.data)

#打印Iris数据集
# print("Iris数据集的标签：\n",label1,data)

"""
2、数据集二:生成服从高斯分布的数据集
"""
# 生成模拟数据
def CreatData(mulist, covlist, N):
    Data = []
    label = []  # 每一个数据来自哪一个分布的标签值
    K = len(mulist)  # k各类别
    for j in range(N):
        i = random.randint(0, K - 1)  # 随机产生一个0~n-1中的数
        data = np.random.multivariate_normal(mulist[i], covlist[i], 1)
        # 产生服从正态分布的随机数
        Data.append(data)
        labeli = i
        label.append(labeli)
    # print(Data)
    Data = np.array(Data)  # 将列表转换成数组
    return Data, label


"""
k为聚类个数,可以自己选择,选出个数最大的前k个作为聚类结果
p为距离的选择,当p=2时为欧式距离
"""
def Hierarchical_Clustering(data, k, p=2):
    # 得到每一个数据点
    X = [(data[k]) for k in range(len(data))]
    # 初始化聚类每一个点为一个类别
    clusters = [id for id in range(len(X))]
    ##计算每个点对之间的距离
    dis2 = {}
    for id1, x1 in enumerate(X):
        for id2, x2 in enumerate(X):
            if (id1 < id2):
                dis = np.sum(abs(x1 - x2) ** p)
                # 注意这里不再进行开方处理，因为是比较大小
                dis2[str(id1) + "-" + str(id2)] = dis  # 表示两点之间的距离
    # 根据距离降序排列
    dis2 = OrderedDict(sorted(dis2.items(), key=itemgetter(1), reverse=True))
    # 类别个数
    cluster_num = len(clusters)
    # 开始聚类
    while cluster_num > k:
        two_idxs, dis = dis2.popitem()
        A = int(two_idxs.split('-')[0])
        B = int(two_idxs.split('-')[1])
        clusterA = clusters[A]
        clusterB = clusters[B]
        # 如果A,B不在一个类别，则将其合并
        if (clusterA != clusterB):
            for id in range(len(clusters)):
                if clusters[id] == clusterB:
                    clusters[id] = clusterA
            cluster_num -= 1
    # print(clusters)
    finalcluster = Counter(clusters).most_common(k)
    # print(finalcluster,'sss')
    finalcluster = [item[0] for item in finalcluster]
    # print(finalcluster,'聚类的类群下标')
    othercluster = [X[id] for id in range(len(X)) if clusters[id] not in finalcluster]
    # print(othercluster,'未归类的点')
    return X, clusters, finalcluster, othercluster


"""
只可视化前两个特征,若要可视化其他特征可修改plt.scatter(cluster[:, 0], cluster[:, 1])代码
"""
def picture(data, k):
    X, clusters, finalcluster, othercluster = Hierarchical_Clustering(data, k)
    for i in range(k):
        cluster = [X[id] for id in range(len(X)) if clusters[id] == finalcluster[i]]
        p=np.array(cluster[0])
        p = p.shape[0]
        cluster = np.array(cluster).reshape(len(cluster), p)
        # print(cluster,len(cluster), '点')
        #散点图
        plt.scatter(cluster[:, 0], cluster[:, 1])
    plt.show()


if __name__ == '__main__':
    """
    1、数据集一
    一次运行一个数据集，另一个注释掉
    """
    #生成模拟数据集
    mulist =  [[-4, 5], [0, 0], [7, 7]]
    mu = np.array(mulist)
    covlist = [[[2, 1], [1, 2]], [[2, 1], [1, 2]], [[2, 1], [1, 2]]]
    cov = np.array(covlist)
    Data, label = CreatData(mu, cov, 300)
    Data1 = Data.reshape(300, 2)
    # print(Data1,'数据')

    '''画出原始数据二维平面分布'''
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    x = Data1[:, 0]
    Y = Data1[:, 1]
    plt.scatter(x, Y, c=label)
    plt.title('数据分布')
    plt.show()
    '''
    查看聚类过程可修改k的参数
    '''
    for k in range(2,6):
        picture(Data1, k)
    X, clusters, finalcluster, othercluster = Hierarchical_Clustering(Data1, 3)
    print(finalcluster)


    """
    2、数据集二
    """
    # x1=data[:,0]
    # x2=data[:,1]
    # plt.scatter(x1, x2,c=label1)
    # plt.title('数据分布')
    # plt.show()
    # for k in range(2,6):
    #     picture(data, k)
    # X1, clusters1, finalcluster1, othercluster1 = Hierarchical_Clustering(data, 3)
    # print(finalcluster1)





