# —*- coding=utf-8 -*-
# @Time:2022/4/2419:58
# @Author:芥末
# @File:逻辑斯蒂.py
# @Software:PyCharm
import pandas as pd
import numpy as np
from sklearn.model_selection import KFold
#读取数据集
'''
共使用了三个数据集
运行该程序，任选一个数据集即可
可使用梯度上升法或者牛顿迭代法（在TestModel函数中选择）
对于交叉验证，采用了五折交叉验证来评估模型
'''
df=pd.read_csv("City1.csv")
# df=pd.read_csv("City2.csv")
# df=pd.read_csv("wilt.csv")

print("该数据集共有{} 行{}列".format(df.shape[0], df.shape[1]))

"""
shuffle=True重新洗牌，每次划分的数据集都不一样
"""
# 划分训练数据集和测试数据集
def Datacut(df):
    kf = KFold(n_splits=5, shuffle=True)  # 初始化KFOLD
    train_files = []  # 存放5折的训练集划分
    test_files = []  # # 存放5折的测试集集划分
    for k, (Trindex, Tsindex) in enumerate(kf.split(df)):
        train_files.append(np.array(df)[Trindex].tolist())
        test_files.append(np.array(df)[Tsindex].tolist())
    return train_files, test_files

#数据标准化  不标准化的数据用梯度上升法得到的结果很差
def NormaData(X):
    mu = np.mean(X, axis=0)
    sigma = np.std(X, axis=0)
    return (X - mu) / sigma

# 数据预处理
def DataClean(data):
    data=np.array(data)
    m=data.shape[0]
    n=data.shape[1]
    # print(m,n,type(data))
    x=data[:,:n-1]#提取特征矩阵
    x=NormaData(x)  #标准化x
    X=np.concatenate((x,np.ones((m,1))),axis=1)#添加一列1
    y=data[:,n-1] #分类标签
    # print(X,y)
    return X,y

#定义Sigmoid函数
def Sigmoid(z):
    f=1/(1+np.exp(-z))
    return f

#1、梯度上升法
"""
eta:学习率
maxiter:最大迭代次数
epsilon:更新阈值
"""
def GradientAscent(X,y,eta=0.001,maxiter=10000,epsilon=1e-5):
    X=np.mat(X)#将数组转换成矩阵形式
    y=np.mat(y).T
    m,n=np.shape(X)
    w=np.ones((n,1))#初始化w
    i=0
    while i < maxiter:
        # z=X*w
        # print(z)
        Grad=X.T*(y-Sigmoid(X*w))#梯度
        w0=w
        w+=eta*Grad #更新w
        i=i+1
        if sum(abs(w-w0))<epsilon:
            break
    return w

#对角矩阵的构造
def Mat(X):
    xlist = []
    for i in range(np.shape(X)[0]):
        xlist.append(X[i, 0])
    D=np.mat(np.diag(xlist))
    return D

#2、牛顿迭代法
"""
maxiter:最大迭代次数
epsilon:更新阈值
"""
def Newtonmethod(X,y,maxiter=1000,epsilon=1e-5):
    X = np.mat(X)  # 将数组转换成矩阵形式
    y = np.mat(y)
    m, n = np.shape(X)
    w = np.zeros((n, 1))  # 初始化w
    i=0
    while i < maxiter:
        w0=w
        Ddiag=np.multiply(Sigmoid(X*w),1-Sigmoid(X*w))#构造D矩阵
        H=(X.T)*Mat(Ddiag)*X
        H=np.linalg.inv(H)#黑塞矩阵
        w-=H*(X.T)*(Sigmoid(X*w)-y.T)#更新w
        i=i+1
        if sum(abs(w-w0))<epsilon:
            break
    return w

#混淆矩阵(模型评估)
def modelmeasure(y, yhat):
    TP, FP, TN, FN = 0, 0, 0, 0
    for i in range(len(y)):
        if y[i] == 1 and yhat[i] == 1:
           TP += 1
        if y[i] == 0 and yhat[i] == 1:
           FP += 1
        if y[i] == 0 and yhat[i] == 0:
           TN += 1
        if y[i] == 1 and yhat[i] == 0:
           FN += 1
    return TP, FP, TN, FN

#预测函数
def Predict(datatest,w):
    x,y=DataClean(datatest)
    m=datatest.shape[0]
    n=datatest.shape[1]
    x=np.mat(x)#转换成矩阵形式，后面要用到矩阵乘法
    Prob=Sigmoid(x*w)#预测概率
    Results=[]#将预测概率结果映射为0、1
    for prob in Prob:
        if prob>=0.5:
            result1=1
            Results.append(result1)
        else:
            result0=0
            Results.append(result0)
    TP,FP,TN,FN=modelmeasure(y,Results)
    print("混淆矩阵",TP,FP,TN,FN)
    #分错个数
    errcount=0
    for i in range(m):
        if datatest[i,n-1]!=Results[i]:
            errcount+=1
    err=errcount/m
    # print("模型分类的错误率为",err)
    return Prob,Results,TP,FP,TN,FN,err

"""
可选择梯度上升法和牛顿迭代法
TRUE是梯度上升法
FALSE是牛顿迭代法
"""
#交叉验证
def TestModel(df,Gradient=False):
    train_files, test_files=Datacut(df)
    wlist=[]
    errlist=[]
    for i in range(5):
        datatrain,datatest=train_files[i],test_files[i]
        datatrain = np.array(datatrain)
        datatest = np.array(datatest)
        X, y = DataClean(datatrain)
        # print(traindata,testdata)
        if Gradient==True:
        #1、梯度上升发
            w=GradientAscent(X,y)
        else:
        #2、牛顿迭代法
            w = Newtonmethod(X, y)

        wlist.append(w)
        # print(w)
        Prob,Results,TP,FP,TN,FN,err = Predict(datatest, w)
        errlist.append(err)
        # print("预测得到的概率:\n",Prob)
        print("预测的结果:\n",Results)
    ave_err=np.average(errlist)
    # print("交叉交叉验证误差为:",ave_err)
    return wlist,ave_err

if __name__ == '__main__':
    w,ave_err=TestModel(df,Gradient=True)#梯度上升法
    # w,ave_err=TestModel(df,Gradient=False)#牛顿迭代法
    print("每次交叉验证模型拟合的参数结果:\n", w)
    print("模型交叉验证误差为:",ave_err)
